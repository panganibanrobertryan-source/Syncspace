# SyncSpace — setup guide

SyncSpace is a responsive Progressive Web App (PWA) starter for phones and tablets. It includes a local demo workspace, file uploads, simple document/spreadsheet/presentation editors, and optional Firebase Authentication + Firestore + Storage cloud sync.

## 1. Run the demo
You need to serve the folder over HTTP/HTTPS (not by opening `index.html` directly). For example:

```bash
python -m http.server 8080
```

Then open `http://localhost:8080`. For a phone, deploy the folder to an HTTPS host such as Firebase Hosting, GitHub Pages, or Netlify. Use the demo button to explore without creating an account.

## 2. Enable cloud accounts and file sync
1. Create a Firebase project at https://console.firebase.google.com/
2. Add a Web App and copy its Firebase config.
3. In `app.js`, replace the `YOUR_...` values in `firebaseConfig`.
4. Enable **Authentication > Sign-in method > Email/Password**.
5. Create a **Cloud Firestore** database.
6. Enable **Storage**.
7. Publish the rules in `firebase.rules.txt` in the matching Firestore and Storage rules editors.
8. Deploy the site to an HTTPS host and refresh.

When Firebase is configured, sign-in/create-account is enabled. Files uploaded while signed in are stored in Firebase Storage; their metadata is saved in Firestore under each user's private `users/{uid}/items` collection.

## 3. Install on Android
Open the deployed HTTPS website in Chrome. Use the browser menu and choose **Install app** or **Add to Home screen**. The PWA manifest and service worker provide an app-like launch experience and cache the app shell.

## Current scope and honest limitations
- The included demo mode saves workspace items in the current browser's local storage. It does not sync between devices.
- Firebase cloud sync requires your own Firebase project configuration and rules. No credentials are included.
- Documents are lightweight text editors; spreadsheets are editable tables; presentations are simple single-slide text layouts. They export as TXT/TSV, not Microsoft Office DOCX/XLSX/PPTX.
- This is an independent web app inspired by cross-device office workflows, not vivo software and not a replacement for vivo's proprietary device integration.
- For real-time multi-device collaboration, office-format compatibility, device pairing, clipboard sync, screen mirroring, and native Android/iPad apps, additional backend and platform-specific development is required.

## Security
Never publish private service-account keys in browser code. The Firebase web config is intended for client apps; access control must be enforced by Firebase Authentication and the rules above. Review rules before production use.
